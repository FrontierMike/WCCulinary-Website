# Handoff: West Coast Culinary Creations — site redesign

## Overview

A fourteen-page marketing site for West Coast Culinary Creations, a one-chef catering and private-dining business run by Janet Wait (Red Seal chef, twelve years as owner-chef of Jan's on the Beach in White Rock). The site serves South Surrey, White Rock and the Lower Mainland.

The design's job is to make the food do the selling. It is a dark site so that saturated food photography is the only colour on the page, and nearly every section is introduced by a photograph. Sections rise into view as the visitor scrolls.

There is an existing Astro codebase for this site (`WCCulinary-Website/`, Astro + Cloudflare Worker). These designs are intended to be rebuilt there.

## About the design files

**The `.dc.html` files in this bundle are design references, not production code.** They are working HTML prototypes that show intended layout, colour, type, copy and behaviour. Do not copy their markup into the app.

The task is to **recreate these designs in the target codebase** — the existing Astro project — using its established patterns: components in `src/components/`, layouts in `src/layouts/`, pages in `src/pages/`, images through `astro:assets`. Copy exact values (hex codes, px sizes, spacing, copy text) out of these files; do not copy their structure.

Each file opens directly in a browser if you want to see it running.

### One caveat about how these files are written

Every style in the prototypes is an **inline `style` attribute**. That is a constraint of the tool they were authored in, not a design intent. In the real build these should become CSS custom properties plus component-scoped styles (see Design Tokens below). Do not ship inline styles.

Three files are shared partials rather than pages: `SiteHeader.dc.html`, `SiteFooter.dc.html`, `FAQ.dc.html`. The pages reference them with a `<dc-import>` tag; in Astro these become three components imported by every page.

## Fidelity

**High fidelity.** Colours, typography, spacing, copy and interaction states are final and should be reproduced closely. Photography is real client photography, already placed.

Two known exceptions, both marked in the copy with square brackets:
- Per-head pricing in the FAQ reads `[per-head rates — to confirm with Jan]`
- Footer contact reads `[Phone — to add]` and `[Instagram — to add]`

Also still placeholder: testimonial quotes on service pages, the six review cards on the Reviews page, and the consulting case study on the gluten-free consulting page. These are marked `data-placeholder` in the source where they appear.

## Design tokens

Taken from the Nocturne design system (`_ds/nocturne-…/styles.css`). Define these as CSS custom properties; do not hard-code the hex values in components.

### Colour

| Token | Value | Used for |
| --- | --- | --- |
| `--color-bg` | `#161826` | Page ground, everywhere |
| `--color-surface` | `#232532` | Image placeholder backgrounds, card fills |
| `--color-text` | `#e9e9ed` | Headings and primary text |
| `--color-accent` | `#9184d9` | Borders on buttons, focus rings |
| `--color-accent-300` | `#d2cefd` | Accent text, links, kickers, button labels |
| `--color-accent-700` | `#5d5294` | Quote rules, subtle accent borders |
| `--color-neutral-200` | `#e4e7f5` | FAQ question text |
| `--color-neutral-300` | `#cfd3e5` | Body copy on dark |
| `--color-neutral-400` | `#b2b6ca` | Secondary/supporting copy |
| `--color-neutral-500` | `#9397ab` | Labels, footer meta, muted text |
| `--color-neutral-600` | `#75798c` | Row numbers on the Services index |
| `--color-neutral-700` | `#595d6c` | Secondary button borders |
| `--color-divider` | `color-mix(in srgb, #e9e9ed 16%, transparent)` | All hairline rules and section separators |

Never pure black or pure white. Do not introduce a second accent.

### Typography

- **Headings:** Instrument Serif, weight 400 only. Never bolder — hierarchy comes from size.
- **Body and UI:** Instrument Sans, weights 400 and 500.
- Loaded from Google Fonts. In the real build, self-host and preload both.

| Role | Size | Other |
| --- | --- | --- |
| Hero `h1` (Home) | `clamp(42px, 6.2vw, 88px)` | line-height 1.02, letter-spacing 0.002em, `text-wrap: balance`, max-width 17ch |
| Page `h1` (interior) | `clamp(40px, 6vw, 84px)` | line-height 1.02 |
| Gallery `h1` | `clamp(48px, 8vw, 110px)` | line-height 0.98, letter-spacing 0.01em |
| Section `h2` | `clamp(32px, 4.4vw, 58px)` | line-height 1.05 |
| Block `h3` | `clamp(28px, 3.2vw, 42px)` | line-height 1.1, max-width 22ch |
| Services row title | `clamp(28px, 3vw, 40px)` | line-height 1.08 |
| Hero lead paragraph | 18.5px | line-height 1.6, colour neutral-300, max-width 52ch |
| Body paragraph | 16px | line-height 1.7, colour neutral-300, max-width 50ch |
| Supporting paragraph | 14.5–15.5px | line-height 1.65–1.68, colour neutral-400 |
| Kicker / eyebrow | 10.5px | letter-spacing 0.26–0.3em, uppercase, colour accent-300 |
| Button label | 12–14px | letter-spacing 0.2–0.22em, uppercase |
| Nav link | 10px | letter-spacing 0.16em, uppercase |
| FAQ question | 16.5px | line-height 1.42 |

Set `text-wrap: pretty` on paragraphs and `text-wrap: balance` on large headings.

**Kicker lines must be width-capped.** Hero kickers sit over photographs; without a `max-width` (44ch is the value used) they run into the bright part of the image and fail contrast. This bit us twice — keep the cap.

### Spacing, radius, elevation

- Content max-width: **1280px**, horizontal padding **32px**.
- Section vertical rhythm: **96px** between alternating blocks, **112–120px** for major sections, `clamp(96px, 12vw, 168px)` for full-bleed call-to-action blocks.
- Radius: `--radius-sm: 4px`, `--radius-md: 8px` (buttons, service row images), `--radius-lg: 14px` (feature images). Gallery tiles use a flat **3px**.
- Elevation: prefer a hairline border (`--color-divider`) over shadow. Shadow tokens exist (`--shadow-sm/md/lg`) but this design does not use them.

## Global patterns

### Header (`SiteHeader.dc.html`)

Sticky, `z-index: 60`, `background: color-mix(in srgb, #161826 82%, transparent)` with `backdrop-filter: blur(16px)`, 1px divider along the bottom. Inner row is max-width 1280px, padding 13px 28px, `display: flex`, `justify-content: space-between`, `align-items: center`, `flex-wrap: wrap`, gap 16px.

- **Left:** wordmark "West Coast Culinary Creations" in Instrument Serif **40px**, `white-space: nowrap`, with "CHEF DESIGNED, CHEF MADE" beneath at 8.5px / 0.24em / uppercase / neutral-500. Links to Home.
- **Right:** nav — Services, Menus, Gallery, Reviews, About — at 10px uppercase, gap 17px, colour neutral-400; the current page's link is accent-300. Then an "Enquire" button: 10px 17px padding, 1px accent border, radius-md, accent-300 label.
- Hover on nav links: accent-300. Hover on Enquire: `background: color-mix(in srgb, var(--color-accent) 16%, transparent)`.

**Responsive note — needs your attention.** At a 40px wordmark the header needs roughly 1050px to hold one line; below that the nav wraps to a second row. It was deliberately set to 40px at the client's request. In the real build, collapse the nav into a menu button below ~1050px. The prototype does not do this.

The active page is passed as a prop (`active="services"` etc.).

### Footer (`SiteFooter.dc.html`)

Top divider, then a max-width 1280px column with padding `72px 32px 40px` and `gap: 60px`, in three stacked rows:

1. **Brand row** — the circular logo (`assets/wccc-logo-circle.png`, rendered **318×318**) beside a 44ch paragraph at 14.5px / neutral-400. `display: flex`, `flex-wrap: wrap`, `align-items: center`, gap 38px. There is deliberately **no** text wordmark here; the logo already contains the name and tagline.
2. **Link row** — `display: grid`, `grid-template-columns: repeat(auto-fit, minmax(140px, 1fr))`, gap 32px. Four equal columns: Services, Explore, Gluten-free, Contact. Each has a 10px / 0.24em / uppercase / neutral-500 label and 14px / neutral-300 links.
3. **Meta row** — top divider, 24px padding-top, copyright left and service area right, both 12px / neutral-500.

**Do not make the brand block a grid sibling of the link columns.** It was originally a 5-unit item in an `auto-fit` grid and stranded a dead cell at laptop widths; then a `flex` version stranded a lone column. Equal columns in their own row is what fixed it. Keep that structure.

### FAQ (`FAQ.dc.html`)

Two-column section (`repeat(auto-fit, minmax(300px, 1fr))`, gap 64px, padding `104px 32px 112px`, top divider):

- **Left:** "BEFORE YOU ASK" kicker, an `h2` (default "Questions people actually ask."), a 34ch supporting line, and a link to Contact.
- **Right:** an accordion. Each row has a 1px top divider, a full-width button (padding 22px 0, transparent, left-aligned, 16.5px, neutral-200 → text on open, accent-300 on hover) and a plus/minus glyph built from two 1.5px bars in accent-300 — the vertical bar animates `scaleY(1) → scaleY(0)` over 0.28s ease when open. Answer body is 14.5px / line-height 1.72 / neutral-300 / max-width 62ch.
- **One panel open at a time.** State is a single index; clicking the open row closes it (index `-1`).

Six shared questions: location, cost, menu customisation, alcohol, notice period, what's included. A `variant` prop splices one service-specific question in at position 3. Variants: `weddings`, `corporate`, `celebrations`, `private-dining`, `wine-dinners`, `gf`.

This appears at the bottom of all seven service pages and the Services index.

### Scroll reveal (`reveal.js`)

The signature interaction. Any element with `data-reveal` fades and rises into place as it enters the viewport.

- Initial: `opacity: 0`, `transform: translateY(22px)`
- Final: `opacity: 1`, `transform: none`
- Transition: `opacity .9s cubic-bezier(.22,.61,.36,1)`, same for transform
- Trigger: `IntersectionObserver`, `rootMargin: '0px 0px -6% 0px'`, `threshold: 0.02`; unobserves after firing so it never replays
- A container with `data-reveal-stagger="80"` gives its direct `data-reveal` children an incremental delay of `index % 8 × 80ms`
- `prefers-reduced-motion: reduce` disables the whole thing — nothing is ever hidden

**Two implementation details that matter.** The script sets **inline styles**, not classes, and tracks primed elements in a `WeakSet`. An earlier class-based version fought the framework's re-renders: elements lost their reveal class, got re-primed, and the page locked up. If you reimplement this, either use inline styles or make sure your framework owns the class. Also: the script never hides anything until JS runs, so content is visible if the script fails.

Hero sections do **not** use `data-reveal` — they use a one-shot CSS animation (`wccHeroRise`, 1s, same easing) so above-the-fold content is never blank.

### Photographic sections

Full-bleed image with `object-fit: cover`, then one or two gradient scrims, then content on top.

Home hero scrims (both `position: absolute; inset: 0`):
```
linear-gradient(to right, rgba(22,24,38,0.94) 0%, rgba(22,24,38,0.72) 46%, rgba(22,24,38,0.18) 100%)
linear-gradient(to top, #161826 1%, rgba(22,24,38,0.15) 46%, rgba(22,24,38,0.5) 100%)
```

Interior page heroes are shorter (`min-height: min(62vh, 540px)`) and use the same pair. **Every photo hero needs both a left-to-right and a bottom-up scrim** — the Gallery hero shipped with only the bottom-up one and its kicker failed contrast over the bright part of the photo.

## Screens

### Home (`Home.dc.html`)

The main page. Top to bottom:

1. **Hero** — `min-height: min(94vh, 880px)`, bottom-aligned content, photo `hero-service.jpg` at `object-position: center 46%`. Kicker (44ch cap), `h1` "Twelve years running a restaurant. Now cooking at your table.", 52ch lead paragraph, two buttons: "Enquire about a date" (accent outline) and "See the food" (neutral-700 outline, links to Gallery). Content padding `160px 32px 96px`.

2. **Five alternating feature blocks** — each a two-column grid (`repeat(auto-fit, minmax(320px, 1fr))`, gap `clamp(32px, 5vw, 80px)`, `align-items: center`, padding `96px 0`, divider on top except the first). Image is 4:3, radius-lg. Blocks 2 and 4 put the image on the right using `order`. Each has a kicker, `h3`, 50ch paragraph, and an uppercase accent link with a 1px underline.

   | # | Kicker | Heading | Image | Links to |
   | --- | --- | --- | --- | --- |
   | 1 | The chef | A Red Seal chef who still cooks every plate herself | `jan-whites.jpg` | About |
   | 2 | The food | Made from scratch, from what is actually in season | `plating.jpg` | Menus |
   | 3 | Private dining | Two to thirty people, in your own kitchen | `private-dining-tacos.jpg` | Private Dining |
   | 4 | Weddings | Intimate weddings, under fifty guests | `svc-weddings.jpg` | Weddings |
   | 5 | Corporate | Office lunches and board dinners that don't taste like catering | `svc-corporate.jpg` | Corporate |

3. **Services catch-all** — top divider, a display-size line ("Celebrations, wine pairing dinners and dedicated gluten-free catering are all on the table too.", `clamp(24px, 2.8vw, 34px)`, 30ch, neutral-300) and a "See all the ways I cook →" link to the Services index.

4. **Recent plates** — `h2` with the "View the full gallery →" **outlined button** beside it (36px gap, left-aligned, baseline-aligned — not pushed to the far edge). Below, exactly **five** square photos in `grid-template-columns: repeat(5, minmax(0, 1fr))`, gap 10px, staggered reveal at 80ms. Hover scales the image to 1.05 over 0.8s. Each tile links to the Gallery.

   The `minmax(0, 1fr)` is important — a pixel floor here overflowed the row and clipped the fifth photo at laptop widths.

5. **Closing call to action** — full-bleed photo (`jan-plating.jpg`, `object-position: center 20%`) with a left-to-right scrim, padding `clamp(96px, 12vw, 168px) 32px`. Kicker, `h2` "Tell Jan the date and she will work with you to decide what she will cook.", 48ch paragraph, "Request a quote" button.

   *The client intends to replace this photo.*

### Gallery (`Gallery.dc.html`)

The page the client most wanted. Hero (62vh, `gal-grazing.jpg`, both scrims) with the word "Gallery" at up to 110px. Then an intro row with a 56ch paragraph and an enquiry link, divider beneath.

Then the grid: `repeat(auto-fill, minmax(218px, 1fr))`, gap 10px, square tiles, 3px radius, hover scale 1.06 over 0.9s. **No lightbox** — clicking does nothing, by request.

**129 photographs.** These are data, not markup — the list lives in the component's logic and renders through one repeated tile. Rebuild it the same way (a content collection or a JSON manifest), not as 129 hand-written elements.

Three things to carry across:

- **Thumbnails are mandatory.** The client's originals are ~6000px and up to 11MB each. The grid loads **480px** JPEGs at quality 0.78 (~35KB each) from `assets/thumb/`. 1100px versions are kept in `assets/gallery-web/` for any future lightbox. Loading the originals locked the browser up completely. In Astro, generate these with `astro:assets` rather than committing derivatives.
- **Order is a fixed shuffle.** The photos are shuffled once with a seeded PRNG (mulberry32, seed `20260815`) so the order looks random but never changes between loads. Reproduce as a baked-in order in the data file — do not shuffle at runtime.
- Every tile carries `loading="lazy"` and `decoding="async"`.

There is a `showRefs` boolean prop that overlays a number on each tile — a curation aid for the client, so they can say "remove 47". Keep it behind a flag or drop it in production.

Closing section: `h2` "Something here you want on your table?", paragraph, "Request a quote" button.

### Services index (`Services.dc.html`)

Hero (58vh, `jan-halibut.jpg`) with "Services" and a 54ch lead. Then seven rows, each a link, each `grid-template-columns: 56px minmax(0, 1fr)` with `gap: clamp(20px, 4vw, 56px)`, padding `44px 0`, top divider (the last also has a bottom divider). The 56px column is a two-digit row number at 12px / 0.18em / neutral-600. The content column is a two-up grid: a 16:10 image at radius-md, then title, 46ch description, "Learn more →". Hover drops the whole row to `opacity: 0.86`.

Order: 01 Private dining, 02 Weddings, 03 Corporate, 04 Celebrations, 05 Wine pairing dinners, 06 Gluten-free catering, 07 Gluten-free consulting.

Then the FAQ (default variant) and a full-bleed call to action ("Not sure which one you need?").

### Service pages

`Weddings`, `Corporate`, `Celebrations`, `Private-Dining`, `Wine-Dinners`, `Gluten-Free-Catering`, `Gluten-Free-Consulting`.

All follow one shape: 62vh photo hero with kicker / `h1` / lead → several content sections (narrative, detail columns, sample menus, a testimonial where one exists) → the FAQ partial with that page's variant → a call to action → footer. Every section below the hero carries `data-reveal`.

Their inline styles are the source of truth for exact values; the shared tokens above cover everything they use. Note these pages predate the current type scale in places and use slightly different sizes (e.g. `clamp(32px, 4.4vw, 58px)` heroes, 22.4px rhythm) — normalise them to the scale above when rebuilding.

Wine Dinners is **private bookings only** — no ticketing, no mailing list. Both gluten-free pages are intentionally **absent from the top nav**, reachable from the footer and the Services index only.

### Other pages

- **Menus** — example menus by service type. Longest page.
- **Reviews** — six review cards. Currently placeholder text; linked from the footer and nav.
- **About** — Jan's story, credentials, the restaurant years.
- **Contact** — the enquiry form. Two sections; the form is the page.

## Interactions and behaviour

| Interaction | Spec |
| --- | --- |
| Section reveal | See `reveal.js` above — 0.9s fade + 22px rise, once, on entry |
| Hero entry | `wccHeroRise` CSS animation, 1s, `cubic-bezier(.22,.61,.36,1)`, 26px rise |
| Photo hover (gallery) | `transform: scale(1.06)`, 0.9s `cubic-bezier(.22,.61,.36,1)` |
| Photo hover (home strip) | `transform: scale(1.05)`, 0.8s, same easing |
| Primary button hover | `background: color-mix(in srgb, var(--color-accent) 16–18%, transparent)` |
| Secondary button hover | `border-color: var(--color-neutral-400)` |
| Text link hover | accent-300 → accent |
| Services row hover | whole row to `opacity: 0.86` |
| FAQ toggle | Open one at a time; vertical bar of the plus glyph `scaleY(0)`, 0.28s ease |
| Focus | `outline: 2px solid var(--color-accent); outline-offset: 2px` — never the browser default |
| Selection | `background: rgba(145,132,217,0.32)` |

No modals, no carousels, no lightbox, no autoplay anywhere on the site.

## State management

Almost none — this is a marketing site.

- **FAQ accordion:** one integer per instance (open index, `-1` for all closed).
- **Header:** current page, for the active nav state. In Astro, derive from the route.
- **Gallery:** a render limit that starts at 60 and lifts to everything 700ms after mount, so first paint isn't blocked by 129 tiles. If your framework streams or paginates natively, use that instead.
- **Contact form:** standard field state and validation. The prototype does not wire up submission — you'll need an endpoint. The existing Cloudflare Worker is the natural home.

## Responsive behaviour

Everything is fluid — `clamp()` for type, `auto-fit`/`auto-fill` grids, `flex-wrap` on rows. There are **no media queries anywhere in the prototypes.** Layouts collapse by grid track count alone.

Two places that need real breakpoints in the build:

1. **The header nav** below ~1050px (see above).
2. **The home strip of five** gets narrow on phones — five tracks at any width. Consider dropping to three below ~600px.

Watch for stranded grid cells generally: an `auto-fit` grid whose item count doesn't divide by the resolved track count leaves visible holes. This caused three separate defects during design. Prefer counts divisible by 2, 3 and 4, or equal-width columns in their own row.

## Assets

**Not included in this bundle** — they are large and the client holds the originals. They live in the project's `assets/` folder.

| Path | Contents |
| --- | --- |
| `assets/wccc-logo-circle.png` | Circular logo, 1080×1080, transparent corners, charcoal disc. Client-supplied. |
| `assets/hero-service.jpg` | Home hero — plated courses on the pass |
| `assets/jan-plating.jpg` | Jan holding two plates — home closing block |
| `assets/jan-whites.jpg`, `janet-bw.jpg`, `jan-halibut.jpg` | Jan portraits |
| `assets/plating.jpg` | Hands garnishing |
| `assets/private-dining-tacos.jpg` | Fish tacos — private dining, 1500px |
| `assets/svc-*.jpg` | Five service header images |
| `assets/gal-*.jpg` | Fifteen curated plate photos |
| `assets/strip-01…18` | Eighteen event photos (`.jpg` and `.png`) |
| `assets/thumb/` | 480px gallery thumbnails, ~35KB each — what the grid loads |
| `assets/gallery-web/` | 1100px versions of the newer photos |

All photography is the client's own. No stock, no illustration, no icons. Watermarked photos credited "Gord Wait" were excluded deliberately — do not reintroduce them.

Alt text: the curated photos have real descriptions. Most of the newer batch carry rotating generic captions ("A plated course from a recent event") because the source filenames are camera IDs. **These should be rewritten with real descriptions before launch** — the client can identify the dishes.

## Files in this bundle

| File | What it is |
| --- | --- |
| `Home.dc.html` | Home page |
| `Gallery.dc.html` | Gallery — 129 photos |
| `Services.dc.html` | Services index |
| `Weddings.dc.html` | Service page |
| `Corporate.dc.html` | Service page |
| `Celebrations.dc.html` | Service page |
| `Private-Dining.dc.html` | Service page |
| `Wine-Dinners.dc.html` | Service page, private bookings only |
| `Gluten-Free-Catering.dc.html` | Service page, not in nav |
| `Gluten-Free-Consulting.dc.html` | Service page for restaurants, not in nav |
| `Menus.dc.html` | Example menus |
| `Reviews.dc.html` | Reviews — placeholder content |
| `About.dc.html` | Jan's story |
| `Contact.dc.html` | Enquiry form |
| `SiteHeader.dc.html` | Shared header partial |
| `SiteFooter.dc.html` | Shared footer partial |
| `FAQ.dc.html` | Shared FAQ accordion, six variants |
| `reveal.js` | Scroll-reveal engine — reusable as-is |

## Before launch

- [ ] Real per-head rates in the FAQ
- [ ] Phone number and Instagram in the footer
- [ ] Six real reviews on the Reviews page
- [ ] Real testimonial quotes on the service pages
- [ ] Consulting case study
- [ ] Replace the home closing-block photo (client is choosing one)
- [ ] Rewrite generic gallery alt text
- [ ] Header nav breakpoint below ~1050px
- [ ] Wire the contact form to an endpoint
- [ ] Google Business Profile URL
