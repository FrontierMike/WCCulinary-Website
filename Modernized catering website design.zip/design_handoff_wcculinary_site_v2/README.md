# Handoff v2: West Coast Culinary Creations — site redesign

## Overview

A fourteen-page marketing site for West Coast Culinary Creations, a one-chef catering and private-dining business run by Janet Wait — Red Seal chef, twelve years as owner-chef of Jan's on the Beach in White Rock. Serving South Surrey, White Rock and the Lower Mainland.

The design's job is to make the food do the selling. Neutral dark grey ground so saturated food photography is the only colour on the page; every one of the fourteen pages opens on a full-bleed photograph; sections rise into view as the visitor scrolls.

There is an existing Astro codebase for this site (`WCCulinary-Website/`, Astro + Cloudflare Worker). These designs are intended to be rebuilt there.

**This is v2.** It supersedes the earlier handoff completely — do not build from that one. See "What changed in v2" at the end if you saw the first package.

## About the design files

**The `.dc.html` files in this bundle are design references, not production code.** They are working HTML prototypes showing intended layout, colour, type, copy and behaviour. Do not copy their markup into the app.

The task is to **recreate these designs in the target codebase** — the existing Astro project — using its established patterns: components in `src/components/`, layouts in `src/layouts/`, pages in `src/pages/`, images through `astro:assets`. Lift exact values (hex codes, px sizes, copy text) out of these files; do not lift their structure.

Each file opens directly in a browser if you want to see it running.

### Two caveats about how these files are written

**1. Every style is an inline `style` attribute.** That is a constraint of the authoring tool, not a design intent. In the real build these become CSS custom properties plus component-scoped styles. Do not ship inline styles.

**2. Colour reaches the pages two different ways.** The pages link the Nocturne design system stylesheet, which defines `--color-bg: #161826` (a blue-purple dark). The client asked for neutral grey, so **every file carries an override** as a second `<style>` block immediately before `</helmet>`:

```html
<style>:root{--color-bg:#1a1a1a;--color-surface:#262626;}</style>
```

In the real build, **set these as the actual token values** and delete the override — don't reproduce the two-layer arrangement.

Three files are shared partials rather than pages: `SiteHeader.dc.html`, `SiteFooter.dc.html`, `FAQ.dc.html`. Pages reference them with `<dc-import>`; in Astro these become three components imported by every page.

## Fidelity

**High fidelity.** Colours, typography, spacing, copy and interaction states are final and should be reproduced closely. Photography is real client photography, already placed.

Placeholders are marked in the source and must be replaced before launch:

| Marker | What it is |
| --- | --- |
| `data-placeholder="review"` | Six drafted review quotes, woven through the home page |
| `data-placeholder="testimonial"` | Seven service-page testimonials (same six quotes, redistributed) |
| `data-placeholder="note"` | A red "ADD REVIEWS HERE" note on the Reviews page |
| `data-placeholder="google-review"` | A dead `href="#"` where the Google Business Profile link goes |
| `[per-head rates — to confirm with Jan]` | Pricing in the FAQ |
| `[Phone — to add]`, `[Instagram — to add]` | Footer contact |

**Every review and testimonial on this site is drafted copy, not a real customer quote.** They are plausible and specific, which makes them dangerous to ship — replace them all with real reviews before launch. This is the single most important item in the package.

## Design tokens

### Colour

| Token | Value | Used for |
| --- | --- | --- |
| `--color-bg` | `#1a1a1a` | Page ground, everywhere |
| `--color-surface` | `#262626` | Image placeholder fills, review cards, tinted section grounds |
| `--color-text` | `#e9e9ed` | Headings and primary text |
| `--color-accent` | `#9184d9` | Button borders, focus rings, the short marks above woven quotes |
| `--color-accent-300` | `#d2cefd` | Accent text, links, kickers, button labels |
| `--color-accent-700` | `#5d5294` | The left rule on service-page testimonials |
| `--color-neutral-200` | `#e4e7f5` | Quote text, FAQ questions |
| `--color-neutral-300` | `#cfd3e5` | Body copy |
| `--color-neutral-400` | `#b2b6ca` | Secondary copy, list descriptions |
| `--color-neutral-500` | `#9397ab` | Labels, quote attributions, footer meta |
| `--color-neutral-600` | `#75798c` | Row numbers on the Services index |
| `--color-neutral-700` | `#595d6c` | Secondary button borders |
| `--color-divider` | `color-mix(in srgb, #e9e9ed 16%, transparent)` | Every hairline rule |

Never pure black or pure white. Do not introduce a second accent.

**Note on the accent.** It is Nocturne's purple, unchanged. Against the original purple-tinted ground it blended; against neutral grey it reads distinctly purple. The client has seen this and accepted it, but if it ever gets revisited, the accent is the thing to change — not the ground.

### Typography

- **Headings:** Instrument Serif, weight 400 only. Hierarchy is size, never weight.
- **Body and UI:** Instrument Sans, weights 400 and 500.
- **Quotes:** Instrument Serif *italic* — this is the only italic in the system and it marks a different voice.
- Loaded from Google Fonts. In the real build, self-host and preload.

| Role | Size | Other |
| --- | --- | --- |
| Home `h1` | `clamp(42px, 6.2vw, 88px)` | line-height 1.02, letter-spacing 0.002em, `text-wrap: balance`, max-width 17ch |
| Interior `h1` | `clamp(32px, 4.4vw, 58px)` | line-height 1.04, letter-spacing −0.012em |
| Gallery `h1` | `clamp(48px, 8vw, 110px)` | line-height 0.98, letter-spacing 0.01em |
| Closing-CTA `h2` | `clamp(36px, 5.4vw, 72px)` | line-height 1.04 |
| Section `h2` | `clamp(34px, 4.4vw, 58px)` | line-height 1.05 |
| "Everything else" `h2` | `clamp(28px, 3.4vw, 44px)` | line-height 1.08, max-width 20ch |
| Block `h3` | `clamp(28px, 3.2vw, 42px)` | line-height 1.1, max-width 22ch |
| Services row title | `clamp(28px, 3vw, 40px)` | line-height 1.08 |
| List row title | `clamp(21px, 2.3vw, 28px)` | line-height 1.14 |
| Hero lead | 18.5px (home), 17.5px (interior) | line-height 1.6–1.64, neutral-300, max-width 52–56ch |
| Body paragraph | 16px | line-height 1.7, neutral-300, max-width 50ch |
| **Woven quote** | **19.5px italic serif** | line-height 1.48, neutral-200, max-width 46ch |
| Quote attribution | 12.5px | neutral-500 → accent-300 on hover |
| Kicker / eyebrow | 10.5px (home), 11.5px (interior) | letter-spacing 0.24–0.3em, uppercase, accent-300 |
| Button label | 14px | letter-spacing 0.2em, uppercase |
| Nav link | 10px | letter-spacing 0.16em, uppercase |

`text-wrap: pretty` on paragraphs, `text-wrap: balance` on large headings.

**Kicker lines must be width-capped at 44ch.** Hero kickers sit over photographs; uncapped they run into the bright part of the image and fail contrast. This bit us twice.

### Spacing, radius, elevation

- Content max-width **1280px** (home, gallery, services) or **1240px** (interior pages) — normalise to one value in the build. Horizontal padding **32px**.
- Vertical rhythm: **96px** between alternating blocks, **112–120px** for major sections, `clamp(96px, 12vw, 168px)` for full-bleed CTAs, **80px** on interior pages.
- Interior pages use a 0.7× density scale inherited from Nocturne, which produces fractional values (`16.8px`, `22.4px`, `33.6px`, `44.8px`). Round these to a clean scale in the build.
- Radius: `--radius-md: 8px` (buttons, service-row images), `--radius-lg: 14px` (feature images). Gallery tiles are a flat **3px**.
- Elevation: a hairline border, never a shadow. Nocturne's shadow tokens exist and are unused.

## Global patterns

### Header (`SiteHeader.dc.html`)

Sticky, `z-index: 60`, `background: color-mix(in srgb, var(--color-bg) 82%, transparent)` with `backdrop-filter: blur(16px)`, bottom divider. Inner row max-width 1280px, padding `13px 28px`, flex, `space-between`, `align-items: center`, `flex-wrap: wrap`, gap 16px.

- **Left:** "West Coast Culinary Creations" in Instrument Serif **40px**, `white-space: nowrap`, with "CHEF DESIGNED, CHEF MADE" beneath at 8.5px / 0.24em / uppercase / neutral-500. Links home.
- **Right:** Services · Menus · Gallery · Reviews · About at 10px uppercase, gap 17px, neutral-400; active page is accent-300. Then "Enquire": padding `10px 17px`, 1px accent border, radius-md.

Active page arrives as a prop (`active="services"`); in Astro, derive from the route.

**Responsive — needs your attention.** At a 40px wordmark the header needs ~1050px to hold one line; below that the nav wraps. The 40px size was the client's explicit request. **Collapse the nav into a menu button below ~1050px in the build.** The prototype does not do this.

### Footer (`SiteFooter.dc.html`)

Top divider, max-width 1280px, padding `72px 32px 40px`, `gap: 60px`, three stacked rows:

1. **Brand row** — the circular logo (`assets/wccc-logo-circle.png`) at **318×318** beside a 44ch paragraph at 14.5px / neutral-400. Flex, wrap, `align-items: center`, gap 38px. Deliberately **no** text wordmark — the logo contains the name and tagline.
2. **Link row** — `grid-template-columns: repeat(auto-fit, minmax(140px, 1fr))`, gap 32px. Four equal columns: Services, Explore, Gluten-free, Contact. 10px / 0.24em / uppercase / neutral-500 labels over 14px / neutral-300 links.
3. **Meta row** — top divider, 24px padding-top, copyright left, service area right, 12px / neutral-500.

**Do not make the brand block a grid sibling of the link columns.** It was a 5-unit item in an `auto-fit` grid and stranded a dead cell at laptop widths; a `flex` version then stranded a lone column. Equal columns in their own row is what fixed it.

### FAQ (`FAQ.dc.html`)

Two-column section (`repeat(auto-fit, minmax(300px, 1fr))`, gap 64px, padding `104px 32px 112px`, top divider):

- **Left:** "BEFORE YOU ASK" kicker, `h2` (default "Questions people actually ask."), a 34ch line, a link to Contact.
- **Right:** an accordion. Each row: 1px top divider, a full-width transparent button (padding `22px 0`, left-aligned, 16.5px, neutral-200 → text on open, accent-300 on hover), and a plus/minus built from two 1.5px accent bars — the vertical bar animates `scaleY(1) → scaleY(0)` over 0.28s ease. Answer body 14.5px / 1.72 / neutral-300 / max-width 62ch.
- **One panel open at a time.** State is a single index; clicking the open row closes it (`-1`).

Six shared questions: location, cost, menu customisation, alcohol, notice period, what's included. A `variant` prop splices one service-specific question in at position 3. Variants: `weddings`, `corporate`, `celebrations`, `private-dining`, `wine-dinners`, `gf`.

Appears at the bottom of six service pages and the Services index. Gluten-Free-Consulting has its own bespoke "Questions" section instead.

### Scroll reveal (`reveal.js`)

The signature interaction, and the thing the client picked this direction for. Reusable as-is.

- Initial `opacity: 0`, `transform: translateY(22px)` → final `opacity: 1`, `transform: none`
- `opacity .9s cubic-bezier(.22,.61,.36,1)`, same for transform
- `IntersectionObserver`, `rootMargin: '0px 0px -6% 0px'`, `threshold: 0.02`; unobserves after firing so it never replays
- `data-reveal-stagger="80"` on a container gives its direct `data-reveal` children `index % 8 × 80ms` delay
- `prefers-reduced-motion: reduce` disables it entirely — nothing is ever hidden
- A `MutationObserver` rescans on DOM change

**Two implementation details that matter.** The script sets **inline styles**, not classes, and tracks primed elements in a `WeakSet`. An earlier class-based version fought the framework's re-renders: elements lost their class, got re-primed, and the page locked up. If you reimplement, either use inline styles or make sure your framework owns the class. Also, nothing is hidden until JS runs, so content survives a script failure.

Heroes do **not** use `data-reveal` — they use a one-shot CSS animation (`wccHeroRise`, 1s, same easing, 26px) so above-the-fold content is never blank.

### Photographic heroes

**All fourteen pages open on one.** Full-bleed image with `object-fit: cover`, then **two** gradient scrims, then bottom-aligned content with `padding: 150px 32px 68px` (160px top on home).

```
linear-gradient(to top,   #1a1a1a 2%, rgba(26,26,26,0.55) 50%, rgba(26,26,26,0.7) 100%)
linear-gradient(to right, rgba(26,26,26,0.92) 0%, rgba(26,26,26,0.7) 44%, rgba(26,26,26,0.2) 100%)
```

**Both scrims are required.** The Gallery hero shipped with only the bottom-up one and its kicker failed contrast over the bright part of the photo.

Two scrim conventions exist in the files: the six older service pages use token-based `color-mix(in srgb, var(--color-bg) 94%, transparent)`, everything else uses literal `rgba(26,26,26,…)`. **Use the token form throughout** — the literals only exist because they predate the grey change.

| Page | Photo | Height |
| --- | --- | --- |
| Home | `hero-service.jpg` | `min(94vh, 880px)` |
| About | `janet-bw.jpg`, grayscale, `object-position: center 34%` | `min(76vh, 720px)` |
| Gallery | `gal-grazing.jpg` | `min(62vh, 560px)` |
| Menus | `gal-lamb.jpg` | `min(62vh, 540px)` |
| Reviews | `svc-celebrations.jpg` | `min(62vh, 540px)` |
| Weddings | `svc-weddings.jpg` | `min(62vh, 540px)` |
| Corporate | `svc-corporate.jpg` | `min(62vh, 540px)` |
| Celebrations | `svc-celebrations.jpg` | `min(62vh, 540px)` |
| Private Dining | `private-dining-tacos.jpg` | `min(62vh, 540px)` |
| Wine Dinners | `gal-lamb.jpg` | `min(62vh, 540px)` |
| GF Catering | `gal-pate.jpg` | `min(62vh, 540px)` |
| Services | `hero-services.jpg` | `min(58vh, 520px)` |
| Contact | `gal-torte.jpg` | `min(58vh, 500px)` |
| GF Consulting | `jan-halibut.jpg` | `min(58vh, 500px)` |

Three photos appear twice: `gal-lamb` (Menus + Wine Dinners), `svc-celebrations` (Reviews + Celebrations), `jan-halibut` (GF Consulting hero + About's colour pair). Worth resolving with fresh photography.

**Hero height must clear the subject.** The About portrait is square and her head occupies ~43% of its height; at 580px the visible slice of a 1920-wide render was only 30% of the image, so her head was cropped no matter where `object-position` sat. It needed 720px. When a hero holds a person, check the maths, don't nudge the crop.

### Review quote (the woven pattern)

Used five times on the home page, inside the alternating blocks, between the paragraph and the block's CTA link:

```html
<div data-placeholder="review" style="margin-top:30px;display:flex;flex-direction:column;
     align-items:flex-start;gap:12px;max-width:46ch">
  <span style="flex:none;width:28px;height:2px;background:var(--color-accent)"></span>
  <p style="font-family:'Instrument Serif',Georgia,serif;font-style:italic;font-size:19.5px;
     line-height:1.48;color:var(--color-neutral-200);text-wrap:pretty">…</p>
  <a href="/reviews" style="font-size:12.5px;color:var(--color-neutral-500)">Wedding, forty guests · Langley →</a>
</div>
```

The 28×2px solid accent bar is Nocturne's "short accent mark" — deliberately not a card, not a left border, not a quotation glyph. Attribution always links through to Reviews.

## Screens

### Home (`Home.dc.html`)

1. **Hero** — `min(94vh, 880px)`, `hero-service.jpg`. Kicker "Private chef & catering · From South Surrey and White Rock to the Lower Mainland" (44ch cap), `h1` "Twelve years running a restaurant. Now cooking at your table.", 52ch lead, two buttons: "Enquire about a date" (accent outline) and "See the food" (neutral-700 outline → Gallery).

2. **Section opener** — "CHEF DESIGNED, CHEF MADE" kicker over "Fine dining, brought to your table." at `clamp(34px, 4.6vw, 62px)`, max-width 24ch.

3. **Five alternating feature blocks** — two-column grid (`repeat(auto-fit, minmax(320px, 1fr))`, gap `clamp(32px, 5vw, 80px)`, `align-items: center`, padding `96px 0`, top divider except the first). Image 4:3 at radius-lg. Blocks 2 and 4 put the image right via `order`. Each carries kicker, `h3`, 50ch paragraph, **a woven review quote**, and an uppercase accent link.

   | # | Kicker | Heading | Image | Link | Quote attribution |
   | --- | --- | --- | --- | --- | --- |
   | 1 | The chef | A Red Seal chef who still cooks every plate herself | `jan-whites.jpg` | About | Wedding, forty guests · Langley |
   | 2 | The food | Made from scratch, from what is actually in season | `plating.jpg` | Menus | Fiftieth birthday · Ocean Park |
   | 3 | Private dining | Two to thirty people, in your own kitchen | `private-dining-tacos.jpg` | Private Dining | Private dinner for ten · South Surrey |
   | 4 | Weddings | Intimate weddings, under fifty guests | `svc-weddings.jpg` | Weddings | Wedding, sixty guests · Crescent Beach |
   | 5 | Corporate | Office lunches and board dinners that don't taste like catering | `svc-corporate.jpg` | Corporate | Corporate client dinner · South Surrey |

4. **Reviews row** — top divider, padding `44px 0 56px`, flex-wrap, gap 36px, `align-items: flex-start`, `space-between`. Three items: a 20ch display line "More reviews, in their own words." at `clamp(24px, 2.8vw, 34px)`, the **sixth** woven quote (36ch, Anniversary dinner at home · White Rock), and the "Read all reviews →" button.

5. **"Everything else" list** — top divider, padding `44px 0 112px`. A header row (kicker + `h2` "Four more ways Jan cooks" + "See all the ways I cook →" button), then four rows, each a link:

   ```
   grid-template-columns: minmax(190px,230px) minmax(0,1fr) auto;
   gap: 8px 28px; align-items: baseline; padding: 22px 0; border-top: 1px solid var(--color-divider);
   ```

   Three direct children: serif title, 15px neutral-400 description, 11.5px uppercase "Learn more →" (`white-space: nowrap`). Last row also has `border-bottom`. Hover drops the row to `opacity: 0.8`.

   Rows: Celebrations · Wine pairing dinners · Gluten-free catering · Gluten-free consulting.

   **This row carries the site's only media query** (see Responsive below). Also: the three children must be *direct* grid children. An earlier version wrapped title and description in a flex span, and each description started wherever its title happened to end — with the longest title pushing its description onto a second line.

6. **Recent plates** — `h2` with "View the full gallery →" beside it (36px gap, `space-between`, baseline). Below, exactly **five** square photos: `grid-template-columns: repeat(5, minmax(0, 1fr))`, gap 10px, staggered reveal at 80ms, hover `scale(1.05)` over 0.8s, each linking to Gallery.

   The `minmax(0, 1fr)` matters — a 190px floor here overflowed the row and clipped the fifth photo at laptop widths, with the scrollbar hidden.

7. **Closing CTA** — full-bleed `jan-plating.jpg` at `object-position: center 20%`, left-to-right scrim, padding `clamp(96px, 12vw, 168px) 32px`. Kicker, `h2` "Tell Jan the date and she will work with you to decide what she will cook.", 48ch paragraph, "Request a quote" button. *The client intends to replace this photo.*

### Gallery (`Gallery.dc.html`)

Hero (62vh, `gal-grazing.jpg`), then an intro row (56ch paragraph + enquiry link, divider beneath), then the grid: `repeat(auto-fill, minmax(218px, 1fr))`, gap 10px, square tiles, 3px radius, hover `scale(1.06)` over 0.9s. **No lightbox** — clicking does nothing, by request.

**128 photographs**, held as data (38 curated + 90 from the client's folder) and rendered through one repeated tile. Rebuild the same way — a content collection or JSON manifest, not 128 hand-written elements.

Four things to carry across:

- **Thumbnails are mandatory.** The client's originals are ~6000px and up to 11MB each. The grid loads **480px** JPEGs at quality 0.78 (~35KB) from `assets/thumb/`. 1100px versions sit in `assets/gallery-web/` for any future lightbox. Loading originals locked the browser up completely. In Astro, generate these with `astro:assets` rather than committing derivatives.
- **Order is a fixed shuffle** — seeded PRNG (mulberry32, seed `20260815`) so it looks random but never changes between loads. Bake the resulting order into the data file; do not shuffle at runtime.
- **First paint is capped at 60 tiles**, lifting to all 128 via a 700ms `setTimeout` after mount. If your framework streams or paginates natively, use that instead.
- Every tile carries `loading="lazy"` and `decoding="async"`.

A `showRefs` boolean prop overlays a number on each tile — a curation aid so the client can say "remove 47". Default `false`. Keep it behind a flag or drop it.

A de-dupe guard filters repeated `src` values, but visual duplicates that are separate files still get through. The client has been pruning these by eye; expect more.

### Services index (`Services.dc.html`)

Hero (58vh, `hero-services.jpg` — hands finishing stuffed peppers). Then seven rows, each a link: `grid-template-columns: 56px minmax(0, 1fr)`, gap `clamp(20px, 4vw, 56px)`, padding `44px 0`, top divider (last also bottom). The 56px column is a two-digit number at 12px / 0.18em / neutral-600. The content column is a two-up grid: 16:10 image at radius-md, then title, 46ch description, "Learn more →". Hover `opacity: 0.86`.

Order: 01 Private dining · 02 Weddings · 03 Corporate · 04 Celebrations · 05 Wine pairing dinners · 06 Gluten-free catering · 07 Gluten-free consulting.

Then the FAQ (default variant) and a full-bleed CTA ("Not sure which one you need?").

### Service pages

`Weddings`, `Corporate`, `Celebrations`, `Private-Dining`, `Wine-Dinners`, `Gluten-Free-Catering`, `Gluten-Free-Consulting`.

One shape: 62vh photo hero (kicker / `h1` / lead) → content sections (narrative, detail columns, sample menus) → **a testimonial** → the FAQ partial with that page's variant → CTA → footer. Every section below the hero carries `data-reveal`.

The testimonial section: top divider, `background: color-mix(in srgb, var(--color-surface) 55%, var(--color-bg))`, padding `72px 32px`, holding a `blockquote` with `padding-left: 22.4px; border-left: 1px solid var(--color-accent-700); max-width: 58ch` — 19px / 1.58 / neutral-200 quote over a 13px / neutral-500 footer — then a "Read all reviews →" link.

Each page gets a different quote, matched to it: Weddings → the sixty-guest hall; Corporate → the quarterly client dinner; Celebrations → the anniversary at home; Private Dining → the clean kitchen; Wine Dinners → talked us into a better menu; GF Catering → the coeliac daughter.

Wine Dinners is **private bookings only** — no ticketing, no mailing list. Both gluten-free pages are intentionally **out of the top nav**, reachable from the footer, the Services index and the home page list.

Gluten-Free-Consulting is the odd one out: B2B (restaurants and kitchens), with its own "Questions" section rather than the FAQ partial, a case-study section that is still placeholder, and no testimonial (restaurant references would read differently from diner reviews).

### Other pages

- **Menus** — example menus by service type. Longest page. `h1` "Every menu here has been cooked. Yours could be one of them."
- **Reviews** — `h1` "Almost all of my work comes from repeat customers." Six review cards (`--color-surface` fill, divider border, radius-lg, `repeat(auto-fit, minmax(300px, 1fr))`, gap 22.4px), then an "ask for a review" section with a mailto and the dead Google link, then a CTA.
- **About** — full-bleed grayscale portrait hero, then narrative, credentials, and a two-up **colour** photo pair (`jan-halibut.jpg`, `jan-plating.jpg`) at `1fr 1fr`, gap 11.2px, 3:4, radius-lg. The pair was grayscale and was changed to colour so the page wasn't flat; the hero stays grayscale because that photo is a monochrome original.
- **Contact** — the enquiry form. The form is the page.

## Interactions

| Interaction | Spec |
| --- | --- |
| Section reveal | 0.9s fade + 22px rise, once, on entry |
| Hero entry | `wccHeroRise`, 1s, `cubic-bezier(.22,.61,.36,1)`, 26px |
| Gallery photo hover | `scale(1.06)`, 0.9s |
| Home strip hover | `scale(1.05)`, 0.8s |
| Outlined button | `padding:16px 32px`, 1px accent border, radius-md, 14px/0.2em uppercase accent-300; hover `background: color-mix(in srgb, var(--color-accent) 18%, transparent)` |
| Secondary button hover | `border-color: var(--color-neutral-400)` |
| Text link hover | accent-300 → accent |
| Quote attribution hover | neutral-500 → accent-300 |
| Services row hover | `opacity: 0.86` |
| List row hover | `opacity: 0.8` |
| FAQ toggle | One at a time; plus glyph's vertical bar `scaleY(0)`, 0.28s ease |
| Focus | `outline: 2px solid var(--color-accent); outline-offset: 2px` |
| Selection | `color-mix(in srgb, var(--color-accent) 32%, transparent)` |

No modals, carousels, lightboxes or autoplay anywhere.

**The three section-closing buttons all carry `margin-left: auto`.** They sit in `space-between` flex rows, which only right-aligns the last item while both children share a line — once a button wraps to its own row it falls back to flex-start. `margin-left: auto` holds the right edge at every width. Applies to "View the full gallery", "Read all reviews" and "See all the ways I cook".

## State management

Almost none — this is a marketing site.

- **FAQ accordion:** one integer per instance (open index, `-1` = closed).
- **Header:** current page for the active nav state; derive from the route.
- **Gallery:** a render limit (60 → all after 700ms) and the `showRefs` flag.
- **Contact form:** field state and validation. The prototype does not wire submission — you need an endpoint. The existing Cloudflare Worker is the natural home.

## Responsive behaviour

Type is `clamp()`, grids are `auto-fit`/`auto-fill`, rows `flex-wrap`. **There is exactly one media query in the entire site:**

```css
@media (max-width:720px){ .svc-row{ grid-template-columns:1fr !important; gap:6px !important; } }
```

It exists because that row has two fixed-width columns (190px minimum + a `nowrap` "Learn more →") which together need ~360px inside a 326px phone viewport. Grid does not wrap, so the `minmax(0,1fr)` middle column absorbed the entire shortfall, went to 0px wide and 432px tall, and rendered the description one character per line. Raising the middle column's floor does not help — only collapsing to one column does.

Two more places needing real breakpoints in the build:

1. **The header nav** below ~1050px — collapse to a menu button.
2. **The home strip of five** is narrow on phones; consider three below ~600px.

**Watch for stranded grid cells.** An `auto-fit` grid whose item count doesn't divide by the resolved track count leaves visible holes. This caused four separate defects during design. Prefer counts divisible by 2, 3 and 4, equal-width columns in their own row, or an explicit track count.

## Assets

**Not included in this bundle** — they are large and the client holds the originals. They live in the project's `assets/` folder.

| Path | Contents |
| --- | --- |
| `assets/wccc-logo-circle.png` | Circular logo, transparent corners, charcoal disc. Client-supplied. Rendered at 318px. |
| `assets/hero-service.jpg` | Home hero — plated courses on the pass |
| `assets/hero-services.jpg` | Services hero — hands finishing stuffed peppers, 1707×1707 |
| `assets/jan-plating.jpg` | Jan holding two plates — home closing block |
| `assets/janet-bw.jpg` | Monochrome portrait — About hero |
| `assets/jan-whites.jpg`, `jan-halibut.jpg` | Jan at work |
| `assets/plating.jpg` | Hands garnishing |
| `assets/private-dining-tacos.jpg` | Fish tacos, 1500px |
| `assets/svc-*.jpg` | Five service header images |
| `assets/gal-*.jpg` | Fifteen curated plate photos |
| `assets/strip-01…18` | Eighteen event photos (`.jpg` and `.png`) |
| `assets/thumb/` | 480px gallery thumbnails, ~35KB each — what the grid loads |
| `assets/gallery-web/` | 1100px versions of the newer photos |

All photography is the client's own. No stock, no illustration, no icons. Watermarked photos credited "Gord Wait" were excluded deliberately — do not reintroduce them.

**Alt text:** the curated photos have real descriptions. Most of the 90-photo batch carry rotating generic captions ("A plated course from a recent event") because the source filenames are camera IDs. Rewrite these before launch — the client can identify the dishes.

## Files in this bundle

| File | What it is |
| --- | --- |
| `Home.dc.html` | Home page |
| `Gallery.dc.html` | Gallery — 128 photos |
| `Services.dc.html` | Services index |
| `Weddings.dc.html` · `Corporate.dc.html` · `Celebrations.dc.html` · `Private-Dining.dc.html` · `Wine-Dinners.dc.html` | Service pages |
| `Gluten-Free-Catering.dc.html` · `Gluten-Free-Consulting.dc.html` | Service pages, not in nav |
| `Menus.dc.html` | Example menus |
| `Reviews.dc.html` | Reviews — placeholder content |
| `About.dc.html` | Jan's story |
| `Contact.dc.html` | Enquiry form |
| `SiteHeader.dc.html` · `SiteFooter.dc.html` · `FAQ.dc.html` | Shared partials |
| `reveal.js` | Scroll-reveal engine — reusable as-is |

## What changed in v2

If you saw the first handoff, these are the differences:

1. **Ground is neutral grey** (`#1a1a1a` / `#262626`), not blue-purple (`#161826` / `#232532`). Hero scrims retuned to match.
2. **Reviews are woven through the home page** — six quotes, one in each of the five blocks plus one in a new reviews row, each linking to the Reviews page. This was the point of the round: build trust.
3. **Seven service pages carry a matched testimonial** above their FAQ (six new, Weddings already had one).
4. **The home page's services catch-all is now a titled four-row list** ("Everything else" / "Four more ways Jan cooks"), replacing a single sentence. Gluten-free consulting was added as the fourth row.
5. **All fourteen pages now have a photo hero.** Reviews, Menus, About, Contact and Gluten-Free-Consulting previously opened on bare text.
6. **About's portrait was promoted** from a boxed image beside the intro to a full-bleed grayscale hero; its photo pair went from grayscale to colour.
7. **Services hero replaced** with `hero-services.jpg` at full resolution.
8. **Three CTA buttons right-align** with `margin-left: auto`.
9. **The `.svc-row` media query** is new — and is the site's only one.
10. **Gallery is down to 128** photos after client pruning.
11. Copy: Menus and Reviews headlines rewritten, "private bookings only" removed from the home list, the Gallery hero kicker removed, "twelve years" throughout (was fourteen), "under fifty guests" for weddings, "two to thirty people" for private dining.

## Before launch

- [ ] **Replace all six drafted reviews with real ones** — highest priority
- [ ] Google Business Profile URL (currently `href="#"`)
- [ ] Real per-head rates in the FAQ
- [ ] Phone number and Instagram in the footer
- [ ] Consulting case study
- [ ] Replace the home closing-block photo (client is choosing one)
- [ ] Resolve the three duplicated hero photos
- [ ] Rewrite generic gallery alt text
- [ ] Header nav breakpoint below ~1050px
- [ ] Wire the contact form to an endpoint
- [ ] Set the grey values as real tokens and delete the `:root` override blocks
- [ ] Normalise content max-width (1240px vs 1280px) and the fractional spacing values
